﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EasysaveGraph2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (var dialog = new FolderBrowserDialog())
            {
                DialogResult result = dialog.ShowDialog();
                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(dialog.SelectedPath))
                {
                    // Utilisez le chemin sélectionné ici
                    textBox2.Text = dialog.SelectedPath;
                    // ...
                }
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (var dialog = new FolderBrowserDialog())
            {
                DialogResult result = dialog.ShowDialog();
                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(dialog.SelectedPath))
                {
                    textBox3.Text = dialog.SelectedPath;
                }
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string cheminProfil = @"C:\Easysave\profils\" + textBox1.Text + ".txt";
            MainWindow.ecrireFichier(cheminProfil, textBox1.Text, false);
            MainWindow.ecrireFichier(cheminProfil, textBox2.Text, false);
            MainWindow.ecrireFichier(cheminProfil, textBox3.Text, false);
            MainWindow.ecrireFichier(cheminProfil, comboBox1.Text, false);
            MainWindow.ecrireFichier(@"C:\Easysave\Profils\listeprofils.txt", textBox1.Text, false);
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
