﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.NetworkInformation;

namespace EasysaveGraph2
{
    public partial class Form4 : Form
    {
        private NetworkMonitor networkMonitor;
        public Form4()
        {
            InitializeComponent();
            networkMonitor = new NetworkMonitor();
        }

        private void btnRetourform1_Click(object sender, EventArgs e)
        {
            Form1 settings = new Form1();
            settings.Show();
        }

        private void AfficherNetwork_Click(object sender, EventArgs e)
        {
            float networkUsage = networkMonitor.GetNetworkUsage();
            textBoxNetwork.Text = "Réseau utilisé: " + networkUsage.ToString("N2") + " bytes/sec";
        }
    }
    public class NetworkMonitor
    {
        private long lastBytesSent;
        private long lastBytesReceived;

        public NetworkMonitor()
        {
            lastBytesSent = 0;
            lastBytesReceived = 0;
        }

        public float GetNetworkUsage()
        {
            long currentBytesSent = 0;
            long currentBytesReceived = 0;

            NetworkInterface[] interfaces = NetworkInterface.GetAllNetworkInterfaces();
            foreach (NetworkInterface ni in interfaces)
            {
                if (ni.OperationalStatus == OperationalStatus.Up)
                {
                    IPv4InterfaceStatistics ipv4Stats = ni.GetIPv4Statistics();
                    currentBytesSent += ipv4Stats.BytesSent;
                    currentBytesReceived += ipv4Stats.BytesReceived;
                }
            }

            long bytesSent = currentBytesSent - lastBytesSent;
            long bytesReceived = currentBytesReceived - lastBytesReceived;

            lastBytesSent = currentBytesSent;
            lastBytesReceived = currentBytesReceived;

            float transferRate = (float)(bytesSent + bytesReceived) / 1.0f;
            return transferRate;
        }
    }

}
