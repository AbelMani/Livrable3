﻿
namespace EasysaveGraph2
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.AfficherNetwork = new System.Windows.Forms.Button();
            this.textBoxNetwork = new System.Windows.Forms.TextBox();
            this.btnRetourform1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(279, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(255, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Surveillance réseau";
            // 
            // AfficherNetwork
            // 
            this.AfficherNetwork.Location = new System.Drawing.Point(575, 279);
            this.AfficherNetwork.Name = "AfficherNetwork";
            this.AfficherNetwork.Size = new System.Drawing.Size(98, 43);
            this.AfficherNetwork.TabIndex = 1;
            this.AfficherNetwork.Text = "Afficher";
            this.AfficherNetwork.UseVisualStyleBackColor = true;
            this.AfficherNetwork.Click += new System.EventHandler(this.AfficherNetwork_Click);
            // 
            // textBoxNetwork
            // 
            this.textBoxNetwork.Location = new System.Drawing.Point(126, 96);
            this.textBoxNetwork.Multiline = true;
            this.textBoxNetwork.Name = "textBoxNetwork";
            this.textBoxNetwork.Size = new System.Drawing.Size(547, 152);
            this.textBoxNetwork.TabIndex = 2;
            // 
            // btnRetourform1
            // 
            this.btnRetourform1.Location = new System.Drawing.Point(126, 279);
            this.btnRetourform1.Name = "btnRetourform1";
            this.btnRetourform1.Size = new System.Drawing.Size(98, 43);
            this.btnRetourform1.TabIndex = 3;
            this.btnRetourform1.Text = "Retour";
            this.btnRetourform1.UseVisualStyleBackColor = true;
            this.btnRetourform1.Click += new System.EventHandler(this.btnRetourform1_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnRetourform1);
            this.Controls.Add(this.textBoxNetwork);
            this.Controls.Add(this.AfficherNetwork);
            this.Controls.Add(this.label1);
            this.Name = "Form4";
            this.Text = "Form4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button AfficherNetwork;
        private System.Windows.Forms.TextBox textBoxNetwork;
        private System.Windows.Forms.Button btnRetourform1;
    }
}