﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Media;

namespace EasysaveGraph2
{
    public partial class Form3 : Form
    {

        public Form3()
        {
            InitializeComponent();
            StreamReader reader = new StreamReader(@"C:\Easysave\Profils\listeprofils.txt");
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                checkedListBox1.Items.Add(line);
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        public void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        private void checkedListBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (var item in checkedListBox1.CheckedItems)
            {
                MainWindow.executeBackup(@"C:\Easysave\Profils\" + item + ".txt", "json");
            }

            this.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Récupérez le texte dans le TextBox
            string texte = textBox1.Text;

            // Ajoutez un saut de ligne au texte s'il n'est pas vide
            if (!string.IsNullOrWhiteSpace(texte))
            {
                texte += "\n";
            }

            // Définissez le chemin du fichier texte
            string cheminFichier = @"C:\Easysave\extensionCRYPT.txt";

            // Écrivez le texte dans le fichier texte en mode Append
            System.IO.File.AppendAllText(cheminFichier, texte);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Définissez le chemin du fichier texte
            string cheminFichier = @"C:\Easysave\extensionCRYPT.txt";

            // Écrivez une chaîne vide dans le fichier texte
            System.IO.File.WriteAllText(cheminFichier, "");
        }
    }
}
