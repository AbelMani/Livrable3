﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace EasysaveGraph2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            StreamReader Lire = new StreamReader(@"C:\Easysave\logs.json"/* + formatLogs*/);
            string line;
            string contenu = "";
            while ((line = Lire.ReadLine()) != null)
            {
                contenu += (line + "\r\n");
            }
            textBox1.Text = contenu;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("explorer.exe", @"C:\Easysave");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        public static long MyVariable { get; set; }

        private void button1_Click(object sender, EventArgs e)
        {
            string input = textBox2.Text;

            try
            {
                long number = long.Parse(input);
                MyVariable = number;
            }
            catch (FormatException)
            {
                MessageBox.Show("La valeur entrée n'est pas un entier valide.");
            }
        }

        private void btnNetwork_Click(object sender, EventArgs e)
        {
            Form4 settings = new Form4();
            settings.Show();
        }
    }
}
